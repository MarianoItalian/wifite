#ifndef VENDOR_H
#define VENDOR_H

char *get_vendor_string(const unsigned char* oui);

#endif


