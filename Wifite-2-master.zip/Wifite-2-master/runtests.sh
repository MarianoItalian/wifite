#!/bin/sh
python2.7 -m unittest discover py/tests -v
